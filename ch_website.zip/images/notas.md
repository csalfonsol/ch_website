### Observaciones conversion y compresión de imágenes

hasta ahora, la mejor opción ha sido el formato webP.
En caso de tener problemas de compatibilidad o navegadores etc..
La segunda opción es el formato **JPG**.

La herramienta online usada fue: https://www.online-convert.com/

NOTA: En caso de convertir a JPG, la mejor opción en relación: calidad/peso fue:

Ajustes de calidad: Bastante buena
Compresión: Alta o media


### Herramientas rapidas de conversion, redimension y mas

iloveimg.com
online-convert.com