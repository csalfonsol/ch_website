* Actualizar datos como consecuencia del cambio de dominio

* Ajustar posicionamiento de titulos, separadores y si aplica, imagenes

* Reducir el tamaño visible de las imagenes (Hacer zoom out)


