
 /* jQuery Pre loader
  -----------------------------------------------*/
$(window).load(function(){

    $('.preloader').fadeOut(1500); // set duration in brackets
});
